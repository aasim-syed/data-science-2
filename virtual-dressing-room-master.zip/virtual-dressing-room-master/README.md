# :womans_clothes: :jeans: virtual-dressing-room :dress: :tshirt: 
virtual fitting rooms possible by the application of augmented reality.  Shoppers get a remarkably accurate picture of how apparel will look and fit on them — in real time and in fluid 3D.

<<<<<<< HEAD
The virtual fitting room platform creates a dramatically more engaging experience for shoppers Bringing them closer to and more engaged with your brand.
 
From increased traffic, higher sales conversions, and fewer product returns to higher perceived brand image, awareness and memory, virtual fitting room is a simple-to-implement turnkey solution that differentiates your brand and improves your bottom line.
 
 [Demo Video](https://drive.google.com/open?id=1Drj86uIJISyLDVpRDpWFXe_x7M4Zppoj)
=======
## To Run the Project
**Run**
```bash
python MainCam.py
```


